﻿using UnityEngine;
using System.Collections;

public class DynamicBlock : MonoBehaviour {

    public int[] ShowForTheseLevels;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
